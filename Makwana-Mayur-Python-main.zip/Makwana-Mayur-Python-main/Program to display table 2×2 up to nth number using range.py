# Program 9
n = int(input("Enter the number up to which you want table of 2: "))
for i in range(1, n+1):
    print(f"2 x {i} = {2*i}")
