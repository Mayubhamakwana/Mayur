# Program 5
fruits = ["apple", "banana", "cherry"]

# Using list functions
fruits.append("orange")
fruits.remove("banana")

# For loop to display
for fruit in fruits:
    print(fruit)
