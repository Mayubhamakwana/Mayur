# Create dictionary first
students = {"Alice": 85, "Bob": 72, "Charlie": 90}

# Update value
students["Bob"] = 75  

# Delete a key
del students["Alice"]  

# Print updated dictionary
print(students)
