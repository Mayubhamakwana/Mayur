import json
data = {"name": "Alice", "marks": 85}
json_str = json.dumps(data)
print(json_str)
