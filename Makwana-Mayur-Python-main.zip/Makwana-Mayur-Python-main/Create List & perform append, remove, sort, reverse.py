lst = [3, 1, 4]
lst.append(2)
lst.remove(1)
lst.sort()
lst.reverse()
print(lst)
