t = (4, 7, 1)
print("Max:", max(t))
print("Min:", min(t))
print("Sum:", sum(t))
