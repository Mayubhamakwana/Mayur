text = "I like Python. Python is fun."
text = text.replace("Python", "Java")
print(text)
