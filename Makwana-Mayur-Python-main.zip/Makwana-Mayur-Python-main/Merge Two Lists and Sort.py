a = [1,3,5]
b = [2,4,6]
c = sorted(a + b)
print(c)
