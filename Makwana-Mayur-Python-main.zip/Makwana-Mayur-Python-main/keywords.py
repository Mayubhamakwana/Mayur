# Program 3
import keyword
print("Python Keywords are:")
print(keyword.kwlist)
