lst = [1,2,3]
t = tuple(lst)
lst2 = list(t)
print(t, lst2)
