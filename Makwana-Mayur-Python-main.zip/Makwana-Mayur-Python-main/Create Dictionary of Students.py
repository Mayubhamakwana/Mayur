students = {"Alice": 85, "Bob": 72, "Charlie": 90}
print(students)
