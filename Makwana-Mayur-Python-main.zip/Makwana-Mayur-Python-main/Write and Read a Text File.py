# Write
with open("file1.txt", "w") as f:
    f.write("Chudasama Maulik.\n")

# Read
with open("file1.txt", "r") as f:
    print(f.read())
