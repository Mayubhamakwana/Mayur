# Program 6
expression = input("Enter a mathematical expression: ")
result = eval(expression)
print("Result:", result)
