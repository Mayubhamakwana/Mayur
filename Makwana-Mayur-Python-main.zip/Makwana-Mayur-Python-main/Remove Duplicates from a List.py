lst = [1,2,2,3,3,3]
lst = list(set(lst))
print(lst)
