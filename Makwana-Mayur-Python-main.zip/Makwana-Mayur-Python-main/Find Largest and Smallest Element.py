lst = [10, 2, 5, 8]
print("Largest:", max(lst))
print("Smallest:", min(lst))
